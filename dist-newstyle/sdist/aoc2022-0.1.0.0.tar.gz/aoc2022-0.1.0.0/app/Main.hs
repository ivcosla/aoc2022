
module Main where
import Data.List (nub)

doSomething :: IO String
doSomething = async "bie"
